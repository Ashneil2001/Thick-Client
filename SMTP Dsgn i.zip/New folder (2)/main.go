package main

import (
	"html/template"
	"log"
	"net/http"
)

var tpl *template.Template

func init() {
	tpl = template.Must(template.ParseGlob("templates/*.gohtml"))
}

func main() {

	http.HandleFunc("/mail", index)
	http.HandleFunc("/unread", unread)
	http.HandleFunc("/other", other)

	http.Handle("/public/", http.StripPrefix("/public", http.FileServer(http.Dir("public"))))
	http.Handle("/assets/", http.StripPrefix("/assets", http.FileServer(http.Dir("assets"))))

	http.ListenAndServe(":8080", nil)
}

func index(res http.ResponseWriter, req *http.Request) {
	c := &http.Cookie{
		Name:  "user-cookie",
		Value: "this would be the value",
		Path:  "/mail",
	}
	http.SetCookie(res, c)

	err := tpl.ExecuteTemplate(res, "inex.gohtml", c)
	if err != nil {
		log.Fatalln("template didn't execute: ", err)
	}
}

func unread(res http.ResponseWriter, req *http.Request) {
	c, err := req.Cookie("user-cookie")
	if err != nil {
		http.SetCookie(res, &http.Cookie{
			Name:  "user-cookie",
			Value: "this would be the value",
			Path:  "/mail",
		})

	}
	err = tpl.ExecuteTemplate(res, "unread.gohtml", c)
	if err != nil {
		log.Fatalln("template didn't execute: ", err)
	}
}

func other(res http.ResponseWriter, req *http.Request) {
	c, err := req.Cookie("user-cookie")
	if err != nil {
		http.SetCookie(res, &http.Cookie{
			Name:  "user-cookie",
			Value: "this would be the value",
			Path:  "/mail",
		})
	}
	err = tpl.ExecuteTemplate(res, "other.gohtml", c)
	if err != nil {
		log.Fatalln("template didn't execute: ", err)
	}
}
